package com.example.proyectofinalprogra5

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast

class Registrar_Rastreo_Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registrar_rastreo)

        val buttonc = findViewById<Button>(R.id.button2);
        buttonc.setOnClickListener() {
            Toast.makeText(this@Registrar_Rastreo_Activity, "Paquete Registrado", Toast.LENGTH_LONG).show();
        }
    }
}