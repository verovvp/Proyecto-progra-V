package com.example.proyectofinalprogra5

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast

class RegistrarActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registrar)

        val buttond = findViewById<Button>(R.id.button);
        buttond.setOnClickListener() {
            Toast.makeText(this@RegistrarActivity, "Acceso Válido", Toast.LENGTH_LONG).show();
        }
    }
}