package com.example.proyectofinalprogra5

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val button = findViewById<Button>(R.id.button3);
        button.setOnClickListener() {
            Toast.makeText(this@MainActivity, "Acceso Válido", Toast.LENGTH_LONG).show();
        }

        val button1 = findViewById<Button>(R.id.button4);
        button1.setOnClickListener() {
            Toast.makeText(this@MainActivity, "Registrarse", Toast.LENGTH_LONG).show();
        }

    }
}