package com.example.proyectofinalprogra5

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast

class VistaRastreoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_vista_rastreo)

        val buttone = findViewById<Button>(R.id.button6);
        buttone.setOnClickListener() {
            Toast.makeText(this@VistaRastreoActivity, "Regresando a Menú Principal", Toast.LENGTH_LONG).show();
        }
    }
}