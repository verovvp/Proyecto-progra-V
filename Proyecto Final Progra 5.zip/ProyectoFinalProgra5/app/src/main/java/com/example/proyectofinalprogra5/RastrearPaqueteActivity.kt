package com.example.proyectofinalprogra5

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast

class RastrearPaqueteActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_rastrear_paquete)

        val buttonb = findViewById<Button>(R.id.button5);
        buttonb.setOnClickListener() {
            Toast.makeText(this@RastrearPaqueteActivity, "Rastrear Pedido", Toast.LENGTH_LONG).show();
        }
    }
}
