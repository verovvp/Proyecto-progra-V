package com.example.pfp5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;

public class MainMenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);

        ImageView imgMapa = (ImageView) findViewById(R.id.imgMapa);
        ImageView imgBox = (ImageView) findViewById(R.id.imgBox);

        imgBox.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent miActivity = new Intent(MainMenuActivity.this, RegistrarRastreo.class);
                startActivity(miActivity);
            }
        });

        imgMapa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent miActivity = new Intent(MainMenuActivity.this, RastrearPaquete.class);
                startActivity(miActivity);
            }
        });
    }
}