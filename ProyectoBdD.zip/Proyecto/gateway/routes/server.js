const express = require('express');
const bodyParser =  require('body-parser');
const router = require('./routes');

const mongoConnection = require('../common/config/db');

const app = express();

const jsonParser = bodyParser.json();
const urlencodedParser = bodyParser.urlencoded({extended: false});

mongoConnection
app.use(jsonParser);
app.use(urlencodedParser);

app.use(router.userRoute);

module.exports = app;