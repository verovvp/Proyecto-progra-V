const express = require('express');
const userRoute = express.Router();

const userController = require('../../user/controllers/user');

userRoute.get('/api/v1/user', async(_req, res) => {
    const data = await userController.getUsers();
    res.send({ status:200, message:'sucess', data: data });
});

userRoute.post('/api/v1/user', async(req, res) => {
 const newUser = {
      Nombre: req.body.Nombre,
      Id: req.body.Id,
      Telefono: req.body.Telefono,
      Direccion: req.body.Direccion,
      Contrasena: req.body.Contrasena,
      ConfirmarCon: req.body.ConfirmarCon,
      

 };
 const result = await userController.createUser(newUser);
 res.send({status: 201, message:'sucess', data: result });
});
module.exports = userRoute;
