const mongoose = require('mongoose');

//Set up default mongoose conecction

const mongoDB = 'mongodb://root:example@localhost:27018'; //String de conexion user es: root contraseña: example
mongoose.connect(mongoDB, {UseNewUrlParser: true, useUnifiedTopology: true});

const mongoConnection = mongoose.connection;

mongoConnection.on('Error', console.error.bind(console, "Mongo DB connection error"));

module.exports = mongoConnection;