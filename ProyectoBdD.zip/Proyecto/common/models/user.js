const mongoose = require('mongoose');

//Define the new schema 

const Schema = mongoose.Schema;
//No existen tablas, se llaman colecciones
const userSchema = new Schema({

    Nombre: String,
    Id: String,
    Telefono: Number,
    Direccion: String,
    Email: String,
    Contrasena: String,
    ConfirmarCon: String,

})

const userModel = mongoose.model('user',userSchema); //Se crea el modelo del esquema

module.exports = userModel;
