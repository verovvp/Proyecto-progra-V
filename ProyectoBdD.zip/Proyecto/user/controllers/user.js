//se encarga de almavenar la logica

const userService = require('../services/user');

const getUsers = async() => {

    const users = await userService.getUsers();
    return users;
}

const createUser = async(user) => {
    return await userService.createUser(user);
}

module.exports = {

    getUsers : getUsers,
    createUser : createUser
}