// Interactua con la DB

const mongoose = require('mongoose');
const userModel = require('../../common/models/user');

const getUsers = async () => { // siempre que usamos el await vamos a utilizar el async 
   const users = await userModel.find();
   return users;

}

const createUser = async (user) =>{
    return await userModel.create({
        Nombre: user.Nombre,
        Id: user.Id,
        Telefono: user.Telefono,
        Direccion: user.Direccion,
        Email: user.Email,
        Contrasena: user.Contrasena,
        ConfirmarCon: user.ConfirmarCon,

    })
}

module.exports = {
    createUser: createUser,
    getUser: getUsers,
}
